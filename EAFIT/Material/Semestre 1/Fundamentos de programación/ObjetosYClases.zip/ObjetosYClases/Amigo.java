
/**
 * Ejemplo de un constructor con problemas.
 * 
 * @version 2017-2
 */
public class Amigo
{
    private String nombre;
    private int unEntero = 10;
    
    public Amigo(String nombre) {
        nombre = nombre;
    }
    
    public static void main(String [] args) {
        Amigo miAmigo = new Amigo("Pedro");
        System.out.println(miAmigo.nombre);
    }
}
