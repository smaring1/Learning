
/**
 * Write a description of class Empleado here.
 * 
 * @author Caperucita 
 * @version Poco antes de conocer al "lobo"
 */
public class Empleado
{
    public String nombre;
    public int salario;
    
    public Empleado(String elNombre, int elSalario) {
        nombre = elNombre;
        salario = elSalario;
    }
    
    public void setSalario(int elSalario) {
        salario = elSalario;
    }
    
}
