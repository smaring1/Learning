
/**
 * Datos del estudiante.
 * 
 */
public class Estudiante
{
    private String nombreEstudiante;
    private int idEstudiante;
    private int creditosAprobados = 0;
    private boolean yaPago = false;
    
    public static final int CREDITOS_PARA_GRADO = 180;
    
    public Estudiante(String nombre, int id) {
        nombreEstudiante = nombre;
        idEstudiante = id;
    }
    
    public String getNombre() {
        return nombreEstudiante;
    }
    
    public int getId() {
        return idEstudiante;
    }
    
    public void setCreditos(int creditos) {
        creditosAprobados = creditos;
    }
    
    public int getCreditosAprobados() {
        return creditosAprobados;
    }
    
    public void setYaPago(boolean pago) {
        yaPago = pago;
    }
    
    public boolean getYaPago() {
        return yaPago;
    }
    
    public static void main(String [] args) {
        Estudiante elMago = new Estudiante("Harry Potter", 123);
        Estudiante juiciosa = new Estudiante("Hermione Granger", 456);
        
        System.out.println("Nombre del mago: " + elMago.getNombre());
        System.out.println("Créditos de la juiciosa: " + 
            juiciosa.getCreditosAprobados());
    }
}
