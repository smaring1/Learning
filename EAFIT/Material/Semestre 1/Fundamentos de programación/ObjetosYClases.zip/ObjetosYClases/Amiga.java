
/**
 * Write a description of class Amiga here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Amiga
{
    private String nombre;
    private String telefono;
    
    public Amiga(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }
    
    public String toString() {
        return nombre + " " + telefono;
    }
    
    public static void main(String [] args) {
        Amiga amiga = null;
        System.out.println("Ella se llama: " + amiga.nombre);
    }
}
