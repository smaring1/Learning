
/**
 * Maneja la información de un rectángulo con lados paralelos
 * a los ejes X e Y.
 *  
 * @version 2017-2
 */
public class Rectangulo
{
    // coordenadas del punto inferior izquierdo
    private int x1;
    private int y1;
    // coordenadas del punto superior derecho
    private int x2;
    private int y2;
    
}
