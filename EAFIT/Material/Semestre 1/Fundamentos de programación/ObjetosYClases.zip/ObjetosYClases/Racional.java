
/**
 * Clase para manejar números Racionales.
 * 
 * @author Basado en el libro The Art and Science of Java (Roberts 2008)
 * @version 2017-2
 */
public class Racional
{
    private int num;            // numerador
    private int den;            // denominador
    
    /**
     * Construye un nuevo número racional
     * @param x numerador del número racional
     * @param y denominador del número racional
     */
    public Racional(int x, int y) {
        int d = mcd(Math.abs(x), Math.abs(y));
        num = x / d;
        den = Math.abs(y) / d;
        if (y < 0)
            num = -num;
    }
    
    /**
     * Retorna la suma de dos números racionales
     * @param r1 primer número racional 
     * @param r2 regundo número racional
     * @return Nuevo número racional con la suma de r1 + r2
     */
    public static Racional sumar(Racional r1, Racional r2) {
        return new Racional(r1.num * r2.den + r2.num * r1.den,
            r1.den * r2.den);
    }
    
    /**
     * Retorna la representación, en String, del número racional
     * @return El String que representa el número racinoal
     */
    public String toString() {
        if(den == 1) {
            return "" + num;
        } else {
            return num + "/" + den;
        }
    }
    
    /**
     * Calcula el máximo común divisor usando el algoritmo de Euclides
     * @param x Primer entero
     * @param y Segundo entero
     * @return Máximo común divisor entre x e y
     */
    public int mcd(int x, int y) {
        int r = x % y;
        while(r != 0) {
            x = y;
            y = r;
            r = x % y;
        }
        return y;
    }
    
    /**
     * Programa principal para hacer pruebas
     */
    public static void main(String [] args) {
        Racional unTercio = new Racional(1, 3);
        System.out.println(unTercio);
        Racional doceTreintaySeisAvos = new Racional(12, 36);
        System.out.println("El otro es: " + doceTreintaySeisAvos);
        Racional r1 = new Racional(1,3);
        Racional r2 = new Racional(1,2);
        Racional r3 = Racional.sumar(r1, r2);
        System.out.println(r3);
    }
}
