
/**
 * Write a description of class Empresa here.
 * 
 * @author El lobo
 * @version Luego de conocer a Caperucita
 */
public class Empresa
{
    private Empleado empleado;
    
    public Empresa(Empleado elEmpleado) {
        empleado = elEmpleado;
    }
    
    public void modificarSalario(int nuevoSalario) {
        empleado.setSalario(nuevoSalario);
    }
}
