
/**
 * Write a description of class Circulo here.
 * 
 * @author Fundamentos de Programación 
 * @version 2017-2
 */
public class Circulo
{
    private double x;
    private double y;
    private double radio;
    
}
